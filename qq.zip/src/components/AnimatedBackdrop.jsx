import { useEffect, useRef } from 'react'

// Cinematic accent trios per variant — used as slow-drifting light sources.
const PALETTES = {
  purple: ['139,92,246', '34,211,238', '52,211,153'],
  cyan:   ['34,211,238', '139,92,246', '52,211,153'],
}

// A quiet, premium "video loop" style ambient backdrop: a handful of soft
// blurred light sources drifting on continuous sine/cosine paths, so the
// motion never resets or jumps — it just flows, like a looping showreel
// background. Renders once as a static frame when prefers-reduced-motion
// is set.
export default function AnimatedBackdrop({ variant = 'purple', density = 1 }) {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const colors = PALETTES[variant] || PALETTES.purple

    let width, height, dpr
    let blobs = []
    let raf
    let parentEl = canvas.parentElement
    const startTime = performance.now()

    const resize = () => {
      const rect = parentEl.getBoundingClientRect()
      width = rect.width
      height = rect.height
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = width * dpr
      canvas.height = height * dpr
      canvas.style.width = width + 'px'
      canvas.style.height = height + 'px'
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      const isMobile = width < 700
      const count = Math.max(2, Math.round((isMobile ? 3 : 4) * density))
      blobs = Array.from({ length: count }, (_, i) => ({
        color: colors[i % colors.length],
        baseX: 0.18 + Math.random() * 0.64,
        baseY: 0.18 + Math.random() * 0.64,
        ampX: 0.14 + Math.random() * 0.12,
        ampY: 0.12 + Math.random() * 0.14,
        speed: 0.00008 + Math.random() * 0.00006,
        phase: Math.random() * Math.PI * 2,
        radiusFrac: (isMobile ? 0.4 : 0.32) + Math.random() * 0.12,
      }))
    }

    const paint = (elapsed) => {
      ctx.clearRect(0, 0, width, height)
      const maxDim = Math.max(width, height)
      blobs.forEach((b) => {
        const t = elapsed * b.speed + b.phase
        const x = (b.baseX + Math.sin(t) * b.ampX) * width
        const y = (b.baseY + Math.cos(t * 0.82) * b.ampY) * height
        const r = b.radiusFrac * maxDim
        const grad = ctx.createRadialGradient(x, y, 0, x, y, r)
        grad.addColorStop(0, `rgba(${b.color},0.4)`)
        grad.addColorStop(0.6, `rgba(${b.color},0.14)`)
        grad.addColorStop(1, `rgba(${b.color},0)`)
        ctx.fillStyle = grad
        ctx.fillRect(0, 0, width, height)
      })
    }

    const tick = (now) => {
      paint(now - startTime)
      raf = requestAnimationFrame(tick)
    }

    resize()
    if (reduceMotion) {
      paint(0)
    } else {
      raf = requestAnimationFrame(tick)
    }

    const ro = new ResizeObserver(resize)
    ro.observe(parentEl)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
    }
  }, [variant, density])

  return <canvas ref={canvasRef} className="animated-backdrop" aria-hidden="true" />
}
